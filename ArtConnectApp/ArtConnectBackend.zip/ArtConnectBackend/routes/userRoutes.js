const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Login user
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Implement token generation or session management here
    res.status(200).json({ message: 'Login successful', userId: user._id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Register a new user
router.post('/register', async (req, res) => {
  try {
    const { fullname, email, password, type } = req.body;
    const newUser = new User({ fullname, email, password, type });
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


// Logout user
router.post('/logout', (req, res) => {
  // Implement token/session invalidation logic here
  console.log('User logged out successfully');
  res.status(200).json({ message: 'Logout successful' });
});

module.exports = router;